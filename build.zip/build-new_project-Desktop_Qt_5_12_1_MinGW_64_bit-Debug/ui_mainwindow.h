/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLineEdit *oper_1;
    QLineEdit *oper_2;
    QLabel *label;
    QLabel *label_2;
    QRadioButton *sum;
    QRadioButton *sub;
    QRadioButton *del;
    QRadioButton *mul;
    QPushButton *result;
    QLabel *label_res;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(389, 127);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        oper_1 = new QLineEdit(centralWidget);
        oper_1->setObjectName(QString::fromUtf8("oper_1"));
        oper_1->setGeometry(QRect(90, 20, 113, 20));
        oper_1->setMaxLength(5);
        oper_2 = new QLineEdit(centralWidget);
        oper_2->setObjectName(QString::fromUtf8("oper_2"));
        oper_2->setGeometry(QRect(220, 20, 113, 20));
        oper_2->setMaxLength(5);
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(120, 0, 71, 16));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(240, 0, 71, 16));
        sum = new QRadioButton(centralWidget);
        sum->setObjectName(QString::fromUtf8("sum"));
        sum->setGeometry(QRect(10, 0, 82, 17));
        sub = new QRadioButton(centralWidget);
        sub->setObjectName(QString::fromUtf8("sub"));
        sub->setGeometry(QRect(10, 20, 82, 17));
        del = new QRadioButton(centralWidget);
        del->setObjectName(QString::fromUtf8("del"));
        del->setGeometry(QRect(10, 40, 82, 17));
        mul = new QRadioButton(centralWidget);
        mul->setObjectName(QString::fromUtf8("mul"));
        mul->setGeometry(QRect(10, 60, 82, 17));
        result = new QPushButton(centralWidget);
        result->setObjectName(QString::fromUtf8("result"));
        result->setGeometry(QRect(100, 50, 91, 23));
        label_res = new QLabel(centralWidget);
        label_res->setObjectName(QString::fromUtf8("label_res"));
        label_res->setGeometry(QRect(220, 50, 161, 20));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 389, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QApplication::translate("MainWindow", "\320\236\320\277\320\265\321\200\320\260\320\275\320\264 1", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "\320\236\320\277\320\265\321\200\320\260\320\275\320\264 2", nullptr));
        sum->setText(QApplication::translate("MainWindow", "\320\241\320\273\320\276\320\266\320\265\320\275\320\270\320\265", nullptr));
        sub->setText(QApplication::translate("MainWindow", "\320\222\321\213\321\207\320\270\321\202\320\260\320\275\320\270\320\265", nullptr));
        del->setText(QApplication::translate("MainWindow", "\320\224\320\265\320\273\320\265\320\275\320\270\320\265", nullptr));
        mul->setText(QApplication::translate("MainWindow", "\320\243\320\274\320\275\320\276\320\266\320\265\320\275\320\270\320\265", nullptr));
        result->setText(QApplication::translate("MainWindow", "\320\237\320\276\321\201\321\207\320\270\321\202\320\260\321\202\321\214", nullptr));
        label_res->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
