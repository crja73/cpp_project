#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    ui->label->setText("hello");
}

void MainWindow::on_push_button_read_text_clicked()
{
    QString stroka;
    stroka.append(ui->raed_text->text());
    ui->label->setText(stroka);
}

void MainWindow::on_nuber_output_button_clicked()  //number output
{
    int num;
    num = 1;
    num *= 5;
    ui->label->setNum(num);
}

void MainWindow::on_set_num_clicked()
{
    QString stroka;
    int num;
    bool flag;

    stroka.append(ui->raed_text->text());
    num = stroka.toInt(&flag);

    if (flag){
        stroka.setNum(num + 12);
    }
    else{
        stroka.clear();
        stroka.append("Введено не число");
    }

    ui->label->setText(stroka);

}
