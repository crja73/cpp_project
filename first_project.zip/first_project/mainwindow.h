#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

    void on_push_button_read_text_clicked();

    void on_nuber_output_button_clicked();

    void on_set_num_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
